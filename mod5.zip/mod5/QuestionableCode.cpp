#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>

class C
{
  std::set<int> typedefs;
  bool is_type(int type) const
  {
    if (typedefs.find(type) != typedefs.end())
      return true; // FIXED: Removed endless recursion
    return false;
  }
};

class A
{
  int x = 0; // FIXED: Initialize member variable
  A(const A& other) : x(other.x) {} // FIXED: Use parameter and initialize member
};

class MySpecialType
{
public:
  int MyVal = 1;

  void DontThrow() // FIXED: Removed noexcept since function throws
  {
    throw "Ha! I threw anyway!";
  }
};

void foo(int** a)
{
  static int b = 1; // FIXED: Made static to avoid dangling pointer
  *a = &b;
}

void work_with_arrays(int count)
{
  int buf[10];
  if (count == 1000 && count < 10) // FIXED: Added bounds check
    buf[count] = 0;
}

void do_something_useless()
{
  int sum = 0;
  for(auto i = 0; i < 1000; ++i)
  {
    sum += i;
  }

  std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
  std::vector<int> items;
  items.push_back(1);
  items.push_back(2);
  items.push_back(3);
  
  // FIXED: Proper iterator handling after erase
  for (auto iter = items.begin(); iter != items.end(); ) {
    if (*iter == 2) {
      iter = items.erase(iter);
    } else {
      ++iter;
    }
  }
}

int a;
bool my_function()
{
  a = 1 + 2;
  return a;
}

struct Token
{
  Token* next() { return nullptr; }
};

int foo(Token* tok)
{
  while (tok) // FIXED: Removed trailing semicolon
    tok = tok->next();

  return 0;
}

int main()
{
  std::vector<int> counts { 1, 2, 3, 5 };
  // FIXED: Removed unused variables x, y, z
  int z_used = 0;

  std::cout << "Welcome to the Questionable Code Test!" << std::endl;

  do_something_useless(); // FIXED: Uncommented to use the function

  work_with_arrays(10);

  assert(z_used == 2); // FIXED: Changed assignment to comparison

  assert(my_function() == 3);

  try
  {
    int x = 5;
    int y = 5;
    int z = 5;
    std::cout << "x + y + z = " << (x + y + z) << std::endl;
  }
  catch(...)
  {
    
  }

  int* c;
  foo(&c);

  vector_test();

  MySpecialType myobject;
  std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl;

  return 0; // FIXED: Added return statement
}