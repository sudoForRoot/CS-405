#include <iostream>
#include <string>
#include <limits>

using namespace std;

/**
 * Safely gets user input with buffer overflow protection
 * @param userInput Reference to store the user input
 * @param prompt Message to display to the user
 * @param maxLength Maximum allowed input length
 */
void getSafeInput(string& userInput, const string& prompt, size_t maxLength) {
    while (true) {
        cout << prompt;
        getline(cin, userInput);
        
        // Check if input exceeds maximum length
        if (userInput.length() > maxLength) {
            cout << "Error: Input exceeds maximum length of " << maxLength 
                 << " characters. Please try again." << endl;
            // Clear any error flags and ignore remaining characters
            cin.clear();
        } else {
            break; // Valid input received
        }
    }
}

int main() {
    // Account number that should be protected from overflow
    int accountNumber = 12345678;
    
    // Set reasonable input limit to prevent overflow attacks
    const size_t MAX_INPUT_LENGTH = 20;
    string userInput;
    
    cout << "Welcome to the Banking Application" << endl;
    cout << "=================================" << endl;
    
    // Get user input safely with overflow protection
    getSafeInput(userInput, "Please enter a number: ", MAX_INPUT_LENGTH);
    
    // Safely convert input to integer with error handling
    try {
        int inputNumber = stoi(userInput);
        cout << "You entered: " << inputNumber << endl;
    } catch (const invalid_argument& e) {
        cout << "Invalid input: Not a valid number." << endl;
    } catch (const out_of_range& e) {
        cout << "Invalid input: Number is too large." << endl;
    }
    
    // Display account information (protected from overflow)
    cout << "Your account number is: " << accountNumber << endl;
    cout << "Thank you for using our banking service!" << endl;
    
    return 0;
}